const { __ } = wp.i18n;

const {
	registerBlockType
} = wp.blocks;

const {
    RichText,
    InspectorControls,
    BlockControls,
	AlignmentToolbar
} = wp.editor;

const {
    PanelBody,
    PanelRow,
    TextControl
} = wp.components;
 
const {
    Fragment
} = wp.element;


registerBlockType('hotblocks/wide-text', {
    title: "Hot Wide Text",
    icon: 'editor-paragraph',
    category: 'hot-blocks',

    supports: {
	    align: true
	},

    attributes: {
    	textString: {
            type: 'array',
            source: 'children',
            selector: 'p'
        },
        alignment: {
			type: 'string',
		}
    },

    // props are passed to edit by default
    // props contains things like setAttributes and attributes
    edit(props) {

        // we are peeling off the things we need
        const {
        	setAttributes,
        	attributes,
        	className, // The class name as a string!
        	focus // this is "true" when the user clicks on the block
        } = props;
        const { alignment } = props.attributes;

        function onTextChange(changes) {
            setAttributes({
                textString: changes
            });
        }

		function onChangeAlignment( updatedAlignment ) {
			setAttributes( { alignment: updatedAlignment } );
		}

        return ([
            <BlockControls key="controls">
                <AlignmentToolbar
					value={ attributes.alignment }
					onChange={ onChangeAlignment }
				/>
            </BlockControls>,
		    <div className={ className }>
		    	<RichText
		            tagName="p"
		            className="content" // adding a class we can target
		            value={attributes.textString}
		            onChange={onTextChange}
		            placeholder={ __('Enter your text here!') }
		            style={{textAlign:  alignment}}
		            />
		    </div>
		]);
    },

    // again, props are automatically passed to save and edit
	save(props) {

	    const { attributes, className } = props;
	    const { alignment } = props.attributes;

	    return (
	        <div className={ className }>
				<p style={ {textAlign: attributes.alignment } }>{attributes.textString}</p>
			</div>
	    );
	}
});